<template>
  <div>
    <!-- <form @submit="addItem">
      <input type="text" v-model="item" />
      <button type="submit" :disabled="!item">Add</button>
    </form>-->
    <register />
  </div>
</template>


<script>
import Register from "./components/Register.vue";
export default {
  name: "App",
  data() {
    return {
      item: "",
      items: []
    };
  },
  methods: {
    addItem() {
      this.items.push(this.item);
      this.item = "";
    }
  },
  components: {
    Register
  }
};
</script>

<style>
</style>
