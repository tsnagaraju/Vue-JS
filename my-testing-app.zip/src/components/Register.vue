<template>
  <div>
    <form @submit.prevent="updateName">
      <p>
        <input type="text" v-model="field.name" />
        <span style="color: red">{{fieldErrors.nameError}}</span>
      </p>
      <button type="submit">Submit</button>
    </form>
  </div>
</template>

<script>
export default {
  name: "Register",
  data() {
    return {
      field: {
        name: ""
      },
      fieldErrors: {
        nameError: ""
      }
    };
  },
  computed: {
    checkName() {
      return this.field.name.length <= 5;
    }
  },
  methods: {
    updateName() {
      if (this.field.name.length <= 5) {
        this.fieldErrors.nameError = "name should be more than 6 chars long";
      } else {
        this.fieldErrors.nameError = "";
      }
    }
  }
};
</script>

<style scoped>
</style>