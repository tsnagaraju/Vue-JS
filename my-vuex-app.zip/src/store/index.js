import Vue from "vue";
import Vuex from "vuex";

Vue.use(Vuex);

const state = {
  products: [],
  name: "nagaraju setti"
}
const getters = {
  getName(state) {
    return state.name;
  },
  getProducts(state) {
    return state.products
  }
}
const mutations = {
  addProduct(state, product) {
    state.products.push(product)
  }
}
const actions = {
  add(context, product) {
    context.commit('addProduct', product)
  }
}

export default new Vuex.Store({
  state,
  getters,
  mutations,
  actions,
  modules: {}
});
