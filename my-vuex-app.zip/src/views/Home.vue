<template>
  <div>
    <p>Name: {{getName}}</p>
    <p>Products Length: {{getProducts.length}}</p>
    <button @click="add">Add</button>
  </div>
</template>

<script>
import { mapGetters } from "vuex";
export default {
  name: "Home",
  computed: mapGetters(["getName", "getProducts"]),
  methods: {
    add() {
      let p = { id: 1, name: "pen", price: 9 };
      this.$store.dispatch("add", p);
    }
  }
};
</script>
