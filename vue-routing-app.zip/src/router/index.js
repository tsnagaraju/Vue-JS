import Vue from "vue";
import VueRouter from "vue-router";
// import Home from "../views/Home.vue";
// import About from '../views/About.vue'
// import Contact from '../views/Contact.vue'

Vue.use(VueRouter);

const routes = [
  {
    path: '/',
    component: () => import('../views/Login.vue')
  },
  {
    path: '/home',
    component: () => import('../views/Home.vue')
  },
  {
    path: '/update',
    name: 'update',
    component: () => import('../views/Update.vue')
  },
  {
    path: '/add',
    component: () => import('../views/Add.vue')
  },
  {
    path: '*',
    component: () => import('../views/PageNotFound.vue')
  }
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

router.afterEach((to) => {
  document.title = to.meta.title
})

router.beforeEach((to, from, next) => {
  let token = localStorage.getItem('user')
  if (to.path != '/' && !token) {
    alert('please login to access home')
    next("/")
  } else {
    next()
  }
})


export default router;
