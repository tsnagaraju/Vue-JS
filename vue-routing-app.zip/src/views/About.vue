<template>
  <div class="about">
    <h1>This page is about {{$route.params.city}}</h1>
  </div>
</template>
