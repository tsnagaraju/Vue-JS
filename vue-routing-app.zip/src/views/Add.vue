<template>
  <div>
    Name:
    <input type="text" v-model="product.name" class="form-control" />
    Price:
    <input type="number" v-model="product.price" class="form-control" />
    <button @click="add" class="btn btn-success">Add</button>
  </div>
</template>

<script>
import { addProduct } from "../project.service";
export default {
  name: "Add",
  data() {
    return {
      product: { name: "", price: 0 }
    };
  },
  methods: {
    add() {
      addProduct(this.product).then(() => {
        alert("added...");
        this.$router.push("/");
      });
    }
  }
};
</script>