<template>
  <div>
    <a href="#" @click="logout" class="btn btn-primary">Logout</a>
    <table class="table">
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Price</th>
      </tr>
      <tr v-for="p in products" :key="p.id">
        <td>{{p.id}}</td>
        <td>{{p.name}}</td>
        <td>{{p.price}}</td>
        <td>
          <router-link :to="{name: 'update', params: {product:p }}" class="btn btn-info">Update</router-link>
        </td>
        <td>
          <button @click="remove(p.id)" class="btn btn-danger">Delete</button>
        </td>
      </tr>
    </table>
    <router-link to="/add" class="btn btn-primary">Add</router-link>
  </div>
</template>

<script>
import { findAllProducts, deleteProduct } from "../project.service";

export default {
  name: "Home",
  components: {},
  data() {
    return {
      products: [],
      perPage: 3,
      currentPage: 1,
      fields: ["id", "name", "price", { key: "actions", label: "" }]
    };
  },
  created() {
    findAllProducts().then(res => (this.products = res.data));
  },
  methods: {
    remove(pid) {
      deleteProduct(pid).then(() => {
        alert("deleted...");
        this.$router.go();
      });
    },
    logout() {
      localStorage.clear();
      this.$router.push("/");
    }
  },
  computed: {
    rows() {
      return this.products.length;
    }
  }
};
</script>
