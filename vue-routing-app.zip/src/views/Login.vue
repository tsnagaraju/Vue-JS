<template>
  <div>
    Username:
    <input type="text" v-model="username" class="form-control" />
    Password:
    <input type="password" v-model="pass" class="form-control" />
    <button @click="login">Login</button>
  </div>
</template>


<script>
export default {
  name: "Login",
  data() {
    return {
      username: "",
      pass: ""
    };
  },
  methods: {
    login() {
      if (this.username == "bean" && this.pass == "123") {
        localStorage.setItem("user", this.username);
        this.$router.push("/home");
      }
    }
  }
};
</script>