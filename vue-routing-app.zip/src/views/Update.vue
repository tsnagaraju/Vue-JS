<template>
  <div>
    ID:
    <input type="number" v-model="product.id" class="form-control" readonly />
    Name:
    <input type="text" v-model="product.name" class="form-control" />
    Price:
    <input type="number" v-model="product.price" class="form-control" />
    <button @click="save" class="btn btn-success">Save</button>
  </div>
</template>

<script>
import { updateProduct } from "../project.service";

export default {
  name: "Update",
  data() {
    return {
      product: this.$route.params.product
    };
  },
  methods: {
    save() {
      updateProduct(this.product).then(() => {
        alert("updated...");
        this.$router.push("/");
      });
    }
  }
};
</script>