<template>
  <div>
    <p>App: {{city}}</p>
    <button @click="sayHello">Click</button>
    <number-display />
    <number-submit>
      Submit
      <ul slot="header">
        <li>
          <a href="#">Home</a>
        </li>
        <li>
          <a href="#">About</a>
        </li>
      </ul>
      <p slot="footer">&copy; reserved by capgemini 2019-20</p>
      <p slot="content" slot-scope="mynum">{{mynum.num}}</p>
    </number-submit>
  </div>
</template>

<script>
import NumberDisplay from "./components/NumberDisplay.vue";
import NumberSubmit from "./components/NumberSubmit.vue";
import AboutVue from "./components/About.vue";

export default {
  name: "App",
  components: {
    // HelloWorld
    // ProductList
    NumberDisplay,
    NumberSubmit
  },
  mixins: [AboutVue]
};
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
