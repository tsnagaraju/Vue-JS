<template>
  <div>
    <p>About Component</p>
  </div>
</template>

<script>
export default {
  name: "About",
  data() {
    return {
      city: "Hyderabad"
    };
  },
  methods: {
    sayHello() {
      alert("Hello, Good Afternoon");
    }
  }
};
</script>


<style scoped>
</style>
