<template>
  <div>
    <p>Contact Component</p>
    <p>Name: {{this.$props.contactName}}</p>
    <p>Mobile: {{contactNumber}}</p>
  </div>
</template>

<script>
export default {
  name: "Contact",
  data() {
    return {};
  },
  props: {
    contactName: String,
    contactNumber: {
      type: Number,
      required: true
    }
  }
};
</script>


<style scoped>
</style>
