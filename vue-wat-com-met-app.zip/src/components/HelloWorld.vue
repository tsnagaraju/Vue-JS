<template>
  <div>
    <form @submit.prevent>
      <input type="text" v-model="name" />
      <br />
      <button type="submit">Submit</button>
    </form>
  </div>
</template>

<script>
export default {
  name: "HelloWorld",
  data() {
    return {
      name: ""
    };
  },
  methods: {
    handleInput(event, msg) {
      alert(event.target.value + " " + msg);
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
