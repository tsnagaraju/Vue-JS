<template>
  <div>
    <contact :contactName="name" :contactNumber="mobile" />
    <!-- <p>{{count}}</p>M:
    <input type="number" v-model="m" />
    <br />KM:
    <input type="number" v-model="km" />-->
    <!-- <div v-for="(t, i) in tabs" :key="i">
      <button @click="currentTab=t">{{t}}</button>
    </div>
    <keep-alive>
      <component v-bind:is="currentTab"></component>
    </keep-alive>-->
    <!-- <p :style="paraStyle">Hello</p>
    <div :class="paraClass">Box</div>-->
  </div>
</template>

<script>
// import Home from "./Home.vue";
// import About from "./About.vue";
import Contact from "./Contact.vue";

export default {
  name: "HelloWorld",
  components: {
    // Home,
    // About,
    Contact
  },
  data() {
    return {
      name: "nagaraju setti",
      mobile: 9848012345,
      m: 0,
      km: 0,
      items: [1, 2, 3],
      tabs: ["home", "about", "contact"],
      currentTab: "home",
      paraColor: "blue",
      bgColor: "red",
      flag: false
    };
  },
  methods: {
    changeName() {
      this.name = "nagaraju setti";
    },
    changeStyle() {
      this.flag = !this.flag;
    }
  },
  watch: {
    m() {
      this.km = this.m ? this.m / 1000 : 0;
    },
    km() {
      this.m = this.km ? this.km * 1000 : 0;
    }
  },
  computed: {
    count() {
      return "the count is: " + this.items.length * 3;
    },
    paraStyle() {
      return {
        color: "white",
        backgroundColor: "blue"
      };
    },
    paraClass() {
      return {
        myDiv: true
      };
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.myDiv {
  color: red;
}
</style>
