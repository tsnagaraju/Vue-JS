<template>
  <div>
    <p>Home Component</p>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {};
  }
};
</script>


<style scoped>
</style>
