<template>
  <div>
    <p>Name: {{name | uppercase}}</p>
    <p>Hello {{name | prepend('Mr')}}</p>
    <p>{{nums}}</p>
  </div>
</template>

<script>
import { EventBus } from "../event_bus.js";

export default {
  name: "NumberDisplay",
  data() {
    return {
      nums: [3, 1, 5, 6],
      name: "nagaraju setti"
    };
  },
  created() {
    EventBus.$on("add-number", number => {
      this.nums.push(number);
    });
  },
  filters: {
    uppercase(value) {
      return value.toUpperCase();
    },
    prepend(value, symbol) {
      return `${symbol}. ${value}`;
    }
  }
};
</script>


<style scoped>
</style>
