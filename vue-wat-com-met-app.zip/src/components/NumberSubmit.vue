<template>
  <div>
    <p>
      <input type="number" v-model="num" />
    </p>
    <button @click="addNumber">
      <slot></slot>
    </button>
    <header>
      <h3>Header</h3>
      <slot name="header"></slot>
    </header>
    <footer>
      <h3>Footer</h3>
      <slot name="footer"></slot>
    </footer>
    <slot name="content" :num="num" />
  </div>
</template>

<script>
import { EventBus } from "../event_bus.js";

export default {
  name: "NumberSubmit",
  data() {
    return {
      num: 0
    };
  },
  methods: {
    addNumber() {
      EventBus.$emit("add-number", Number(this.num));
    }
  }
};
</script>


<style scoped>
</style>
