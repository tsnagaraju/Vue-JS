<template>
  <div>
    <div class="main">
      <div class="image">
        <img :src="product.iurl" />
      </div>
      <div class="cont">
        <div>ID: {{product.id}}</div>
        <div>Name: {{product.name}}</div>
        <div>Price: {{product.price}}</div>
        <div>
          <!-- <a href="#" @click="handleLikes(product.id)">Likes: {{product.likes}}</a> -->
          <a href="#" @click="$emit('update', product.id)">Likes: {{product.likes}}</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "Product",
  props: {
    product: Object,
    handleLikes: Function
  }
};
</script>


<style scoped>
.main {
  width: 300px;
  height: 100px;
  border: 1px solid red;
  margin-left: 100px;
}
.image {
  width: 30%;
  height: 100%;
  float: left;
}
.cont {
  width: 70%;
  height: 100%;
  float: right;
}
img {
  width: 100px;
  height: 100px;
}
a {
  text-decoration: none;
}
</style>
