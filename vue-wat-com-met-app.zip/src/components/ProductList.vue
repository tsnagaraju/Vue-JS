<template>
  <div>
    <p v-for="p in products" :key="p.id">
      <product :product="p" :handleLikes="updateLikes" @update="updateLikes" />
    </p>
  </div>
</template>

<script>
import Product from "./Product.vue";

export default {
  name: "ProductList",
  components: {
    Product
  },
  data() {
    return {
      products: [
        {
          id: 1,
          name: "iphone 6s",
          price: 8999,
          iurl: "images/iphone_6s.jpg",
          likes: 1
        },
        {
          id: 2,
          name: "iphone 5E",
          price: 6999,
          iurl: "images/iphone_6s.jpg",
          likes: 1
        },
        {
          id: 3,
          name: "iphone XR",
          price: 9999,
          iurl: "images/iphone_6s.jpg",
          likes: 1
        }
      ]
    };
  },
  methods: {
    updateLikes(pid) {
      this.products.map(p => {
        if (p.id == pid) {
          p.likes += 1;
        }
      });
    }
  }
};
</script>


<style scoped>
</style>
