<template>
  <div>
    <input type="text" v-model="task" />
    <button @click="addTask">Add Task</button>
    <ul>
      <li v-for="(t, idx) in todos" :key="idx">
        {{t}}
        <button @click="removeTask(idx)">Remove</button>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "TodoList",
  data() {
    return {
      todos: [],
      task: ""
    };
  },
  methods: {
    addTask() {
      this.todos.push(this.task);
    },
    removeTask(index) {
      this.todos.splice(index, 1);
    }
  }
};
</script>


<style scoped>
</style>
